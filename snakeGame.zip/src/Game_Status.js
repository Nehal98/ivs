
function GameStatus(){

    return(
    <div id ='game_alert' className='alert_class'>
        
    </div>

    );
}

export default GameStatus;